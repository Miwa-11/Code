#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

//Riff
const string CHUNK_ID = "RIFF";
const string CHUNK_SIZE = "----";
const string FORMAT = "WAVE";

//FMT
const string SUBCHUNK1_ID = "fmt ";
const int SUBCHUNK1_SIZE = 16;
const int AUDIO_FORMAT = 1;
const int NUM_CHANNELS = 2;
const int SAMPLE_RATE = 44100;
const int BYTE_RATE = SAMPLE_RATE * NUM_CHANNELS * (SUBCHUNK1_SIZE / 8);
const int BLOCK_ALIGN = NUM_CHANNELS * (SUBCHUNK1_SIZE / 8);
const int BITS_PER_SAMPLE = 16;

//data
const string SUBCHUNK2_ID = "data";
const string SUBCHUNK2_SIZE = "----";

const int MAX_AMPLITUDE = 32760;//can change: higher number = closer waves
const int VOLUME = 5; // number 1 - 10;
const int MAX_VOLUME = (MAX_AMPLITUDE * VOLUME) / 10;

//functions
void writeAsBytes(ofstream& file, int value, int byteSize);
void writeNote(double pitch, int octave, double duration, int volume, ofstream& wav);

//note frequencies
const double A = 110.00;
const double Bb = 116.54;
const double B = 123.47;
const double C = 130.81;
const double Db = 138.59;
const double D = 146.83;
const double Eb = 155.56;
const double E = 164.81;
const double F = 174.61;
const double Gb = 185.00;
const double G = 196.00;
const double Ab = 207.65;



int main()
{
	ofstream wav;
	wav.open("A Whole New World.wav", ios::binary);

	if (wav.is_open())
	{
		wav << CHUNK_ID;
		wav << CHUNK_SIZE;
		wav << FORMAT;

		wav << SUBCHUNK1_ID;
		writeAsBytes(wav, SUBCHUNK1_SIZE, 4);
		writeAsBytes(wav, AUDIO_FORMAT, 2);
		writeAsBytes(wav, NUM_CHANNELS, 2);
		writeAsBytes(wav, SAMPLE_RATE, 4);
		writeAsBytes(wav, BYTE_RATE, 4);
		writeAsBytes(wav, BLOCK_ALIGN, 2);
		writeAsBytes(wav, BITS_PER_SAMPLE, 2);

		wav << SUBCHUNK2_ID;
		wav << SUBCHUNK2_SIZE;

		int startAudio = wav.tellp();

		writeNote(B, 3, 0.5, 1, wav); //A
		writeNote(C, 4, 0.5, 1, wav);//Whole
		writeNote(E, 4, 0.5, 1, wav); //new
		writeNote(D, 4, 1.5, 1, wav); //world
		writeNote(B, 3, 0.5, 1, wav); //A
		writeNote(C, 3, 0.5, 1, wav);//new
		writeNote(E, 4, 0.5, 1, wav);//fanta-
		writeNote(D, 3, 0.5, 1, wav);//stic
		writeNote(A, 3, 0.5, 1, wav);//point
		writeNote(C, 3, 0.4, 1, wav);//of
		writeNote(B, 3, 0.4, 1, wav);//vi-
		writeNote(B, 3, 0.5, 1, wav);//ew
		int endAudio = wav.tellp();

		wav.seekp(startAudio - 4);
		writeAsBytes(wav, endAudio - startAudio, 4);

		wav.seekp(4, ios::beg);
		writeAsBytes(wav, endAudio - 8, 4);
	}
	wav.close();
	return 0;
}

void writeAsBytes(ofstream& file, int value, int byteSize)
{
	file.write(reinterpret_cast<const char*>(&value), byteSize);
}

void writeNote(double pitch, int octave, double duration, int volume, ofstream& wav)
{
	double frequency = pitch * pow(2, octave);
	for (int i = 0; i < SAMPLE_RATE * duration; i++)
	{
		int maxVolume = (MAX_VOLUME * volume) / 10;
		double amplitude = (double)i / SAMPLE_RATE * maxVolume;
		double value = sin((2 * 3.14 * i * frequency) / SAMPLE_RATE);

		double channel1 = amplitude * value / duration;
		double channel2 = (maxVolume - amplitude) * value / duration;

		writeAsBytes(wav, channel1, 2);
		writeAsBytes(wav, channel2, 2);
	}
}
